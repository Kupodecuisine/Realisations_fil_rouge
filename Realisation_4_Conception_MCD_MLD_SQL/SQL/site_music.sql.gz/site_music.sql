-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 26 nov. 2021 à 15:27
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `site_music`
--

-- --------------------------------------------------------

--
-- Structure de la table `abonnement`
--

DROP TABLE IF EXISTS `abonnement`;
CREATE TABLE IF NOT EXISTS `abonnement` (
  `id_utilisateur_n` int(11) NOT NULL,
  `id_utilisateur` int(11) NOT NULL,
  PRIMARY KEY (`id_utilisateur`,`id_utilisateur_n`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `associer`
--

DROP TABLE IF EXISTS `associer`;
CREATE TABLE IF NOT EXISTS `associer` (
  `id_morceau` int(11) NOT NULL,
  `id_illustration` int(11) NOT NULL,
  PRIMARY KEY (`id_morceau`,`id_illustration`),
  KEY `id_illustration` (`id_illustration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

DROP TABLE IF EXISTS `commentaire`;
CREATE TABLE IF NOT EXISTS `commentaire` (
  `id_commentaire` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo_utilisateur_commentaire` varchar(100) DEFAULT NULL,
  `contenu_commentaire` text,
  `date_commentaire` datetime DEFAULT NULL,
  `id_utilisateur` int(11) DEFAULT NULL,
  `id_morceau` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_commentaire`),
  KEY `fk_commentaire_utilisateur` (`id_utilisateur`),
  KEY `fk_commentaire_morceau` (`id_morceau`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `icone_like`
--

DROP TABLE IF EXISTS `icone_like`;
CREATE TABLE IF NOT EXISTS `icone_like` (
  `id_icone_like` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo_utilisateur_like` varchar(100) DEFAULT NULL,
  `date_like` datetime DEFAULT NULL,
  `id_utilisateur` int(11) DEFAULT NULL,
  `id_morceau` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_icone_like`),
  KEY `fk_icone_like_utilisateur` (`id_utilisateur`),
  KEY `fk_icone_like_morceau` (`id_morceau`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `illustration`
--

DROP TABLE IF EXISTS `illustration`;
CREATE TABLE IF NOT EXISTS `illustration` (
  `id_illustration` int(11) NOT NULL AUTO_INCREMENT,
  `nom_illustration` varchar(50) DEFAULT NULL,
  `createur_illustration` varchar(100) DEFAULT NULL,
  `date_post_illustration` datetime DEFAULT NULL,
  PRIMARY KEY (`id_illustration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `morceau`
--

DROP TABLE IF EXISTS `morceau`;
CREATE TABLE IF NOT EXISTS `morceau` (
  `id_morceau` int(11) NOT NULL AUTO_INCREMENT,
  `nom_morceau` varchar(100) DEFAULT NULL,
  `compositeur_morceau` varchar(100) DEFAULT NULL,
  `duree_morceau` time DEFAULT NULL,
  `date_post_morceau` datetime DEFAULT NULL,
  `id_utilisateur` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_morceau`),
  KEY `fk_morceau_utilisateur` (`id_utilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `repost`
--

DROP TABLE IF EXISTS `repost`;
CREATE TABLE IF NOT EXISTS `repost` (
  `id_repost` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo_utilisateur_repost` varchar(100) DEFAULT NULL,
  `date_repost` datetime DEFAULT NULL,
  `id_utilisateur` int(11) DEFAULT NULL,
  `id_morceau` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_repost`),
  KEY `fk_repost_utilisateur` (`id_utilisateur`),
  KEY `fk_repost_morceau` (`id_morceau`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id_utilisateur` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo_utilisateur` varchar(100) DEFAULT NULL,
  `nom_utilisateur` varchar(30) DEFAULT NULL,
  `prenom_utilisateur` varchar(30) DEFAULT NULL,
  `mail_utilisateur` varchar(100) DEFAULT NULL,
  `log_utilisateur` varchar(50) DEFAULT NULL,
  `mdp_utilisateur` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_utilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `abonnement`
--
ALTER TABLE `abonnement`
  ADD CONSTRAINT `abonnement_ibfk_1` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`id_utilisateur`);

--
-- Contraintes pour la table `associer`
--
ALTER TABLE `associer`
  ADD CONSTRAINT `associer_ibfk_1` FOREIGN KEY (`id_morceau`) REFERENCES `morceau` (`id_morceau`),
  ADD CONSTRAINT `associer_ibfk_2` FOREIGN KEY (`id_illustration`) REFERENCES `illustration` (`id_illustration`);

--
-- Contraintes pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD CONSTRAINT `fk_commentaire_morceau` FOREIGN KEY (`id_morceau`) REFERENCES `morceau` (`id_morceau`),
  ADD CONSTRAINT `fk_commentaire_utilisateur` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`id_utilisateur`);

--
-- Contraintes pour la table `icone_like`
--
ALTER TABLE `icone_like`
  ADD CONSTRAINT `fk_icone_like_morceau` FOREIGN KEY (`id_morceau`) REFERENCES `morceau` (`id_morceau`),
  ADD CONSTRAINT `fk_icone_like_utilisateur` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`id_utilisateur`);

--
-- Contraintes pour la table `morceau`
--
ALTER TABLE `morceau`
  ADD CONSTRAINT `fk_morceau_utilisateur` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`id_utilisateur`);

--
-- Contraintes pour la table `repost`
--
ALTER TABLE `repost`
  ADD CONSTRAINT `fk_repost_morceau` FOREIGN KEY (`id_morceau`) REFERENCES `morceau` (`id_morceau`),
  ADD CONSTRAINT `fk_repost_utilisateur` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`id_utilisateur`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
